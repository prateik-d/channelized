# Linkedin API integration in PHP based Web App

### Full Tutorial: http://thinkdiff.net/linkedin/integrate-linkedin-api-in-your-site/

✔ Users can bring linkedin profile and network in your site 

✔ There are 52 millions users in linkedin so you can engage them in your site

✔ You may create authentication through linkedin api so that user don't need to register in your site

✔ You can search profile, connection

✔ Users can also update their status from your site using linkedin apis

