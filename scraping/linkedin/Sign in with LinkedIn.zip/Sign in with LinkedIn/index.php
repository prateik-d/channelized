<?php
require "init.php";
?>
<a href="<?php echo $linkedin->getAuthUrl() ?>" style="font-size: large;">Sign in with LinkedIn</a>