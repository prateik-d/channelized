<?php

use myPHPNotes\LinkedIn;

require_once "LinkedIn.php";

$app_id = "81x0c1ym6tbd5a";
$app_secret = "ZGOlp2MfaCIfrH1c";
$callback = "http://localhost/callback.php";
$scopes = "r_emailaddress r_basicprofile r_liteprofile";
$ssl = false; //TRUE FOR PRODUCTION ENV.

$linkedin = new LinkedIn($app_id, $app_secret, $callback, $scopes, $ssl);